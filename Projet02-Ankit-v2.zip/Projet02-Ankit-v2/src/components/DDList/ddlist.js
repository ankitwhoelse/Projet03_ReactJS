import React, { Component } from 'react'

export default class DDList extends Component{
    constructor(props) {
        super(props) 

        this.state = {
            regions: [],
            provinces: [],
           // regions: ['Atlantique', 'Centre', 'Prairies', 'Cote Ouest', 'Territoires du Nord'],
           // provinces: ['Alberta', 'Colombie-Britannique', 'Ile-du-Prince-Édouard', 'Manitoba', 'Nouveau-Brunswick', 'Nouvelle-Écosse', 'Ontario', 'Québec', 'Saskatchewan', 'Terre-Neuve-et-Labrador', 'Nunavut', 'Territoires du Nord\'Ouest', 'Yukon'],
            strFiltre: ''
        }
    }

    handleChange = (event) => {
        this.setState({ strFiltre: event.target.value });
    }

    componentDidMount() {
        fetch('http://localhost:3050/provinces')
         .then(function(res) {
             return res.json();
         }).then((jsonData)=> {
             console.log("Les provinces du Canada: " + jsonData.provinces)
             this.setState({
                provinces: jsonData.provinces
             })
         });
         fetch('http://localhost:3050/regions')
         .then(function(res2) {
             return res2.json();
         }).then((jsonData)=> {
             console.log("Les regions du Canada: " + jsonData.regions)
             this.setState({
                regions: jsonData.regions
             })
         });
     }

    render() {
        return (
            <div>
                <span>Dropdown Lists non liées:&nbsp;&nbsp;</span>
                <div className="row">
                    <div className="col-sm-6">
                        <select autoFocus>
                            <option value="0">Choisir votre province</option>
                            {this.state.provinces.map(prov => {
                               return (
                                    <option key={prov}>{prov}</option>
                               );
                            })}
                        </select>
                    </div>

                    <div className="col-sm-6">
                        <select autoFocus>
                            <option value="0">Choisir votre région</option>
                            {this.state.regions.map(regi => {
                               return (
                                    <option key={regi}>{regi}</option>
                               );
                            })}
                        </select>
                    </div>
                </div>
                &nbsp;
            </div>
        )
    }
}