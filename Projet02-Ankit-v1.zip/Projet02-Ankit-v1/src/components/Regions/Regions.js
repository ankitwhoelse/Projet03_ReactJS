import React, { Component } from 'react'

export default class Regions extends Component {
    constructor(props) {
        super(props)

        this.state = {
            regions: ['Atlantique', 'Centre', 'Prairies', 'Cote Ouest', 'Territoires du Nord'],
            strFiltre: ''
        }
    }

        handleChange = (event) => {
            this.setState({ strFiltre: event.target.value });
        }
    
        componentDidMount() {
            fetch('http://localhost:3050/regions')
             .then(function(res) {
                 return res.json();
             }).then((jsonData)=> {
                 console.log("Les régions du Canada: " + jsonData.regions)
                 this.setState({
                    regions: jsonData.regions
                 })
             });
         }
    
        render() {
            console.log("Régions: " + this.state.regions)
            let binRegionsFound = this.state.regions.some(
                region=>region
                    .toUpperCase()
                    .includes(this.state.strFiltre.toUpperCase())
                ) 
            
            return (
                <div>
                    <span>Régions contenant les lettres:&nbsp;&nbsp;</span>
                    <input
                        id="filtreId"
                        type="text"
                        value={this.state.strFiltre}
                        onChange={this.handleChange}
                    />
                    <ul> {this.state.strFiltre} </ul>
                    <ul>
                        {this.state.regions.map(currRegion => {
                            return (
                                currRegion
                                    .toUpperCase()
                                    .includes(this.state.strFiltre.toUpperCase()) && (
                                        <li key={currRegion}>
                                            {currRegion}
                                        </li>
                                    )
                            );
                        })}
                        {!binRegionsFound && <li> No states found </li>}                    
                    </ul>
                </div>
                
            )
        }
    
}
    

