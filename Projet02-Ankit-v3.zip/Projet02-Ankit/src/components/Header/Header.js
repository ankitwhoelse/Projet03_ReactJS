import React, { Component } from 'react'
import "./Header.css"
import {Link} from "react-router-dom";

export default class Header extends Component {
    render() {
        return (
            <header className="header">
                <div className="row">
                    <div className="col-sm-3">
                        <div className="canada_flag" />
                    </div>
                    <div className="col-sm-6">
                        <h3>Projet final</h3>
                        <div>Outils de programmation Web</div>
                        <div>Cégep Gérald Godin</div>
                    </div>
                    <div className="col-sm-3">
                        <h4>Filtrer par</h4>
                        <div><li><Link to="/Provinces">Provinces</Link></li></div>
                        <div><li><Link to="/Regions">Régions</Link></li></div>
                        <div><li><Link to="/DDList">Drop Down List</Link></li></div>
                        <div><li><Link to="/DDListOrg">Listes Liées</Link></li></div>
                    </div>
                </div>
            </header>
        )
    }
}
