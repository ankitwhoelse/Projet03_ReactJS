import React, { Component } from 'react'

export default class DDListOrg extends Component{
    constructor(props) {
        super(props) 

        this.state = {
            regionProvinces: {},
            provinces: []
        }
    }

    componentDidMount() {
        fetch('http://localhost:3050/regionProvinces')
            .then(function (res) {
                return res.json();
            }).then((jsonData) => {
                console.log("Les provinces des différentes régions du Canada: " + (jsonData.regionProvinces))
                this.setState({
                    regionProvinces: jsonData
                })
            });
    }

    handleChange = (event) => {
        this.setState({
            provinces: this.state.regionProvinces[event.target.value]
        })
    }

    render() {
        return (
            <div>
                <span>Listes liées:&nbsp;&nbsp;</span>
                <div className="row">
                    <div className="col-sm-6">
                        <select autoFocus onChange={this.handleChange}>
                   {/*          <option value='Choisir votre région'>Choisir votre région</option> */}
                            {Object.keys(this.state.regionProvinces).map(region => {
                                return (
                                    <option value={region}>{region}</option>
                                );
                            })}
                        </select>
                    </div>
                    <div className="col-sm-6">
                        <select>
                            {/* <option value='Choisir votre région'>Choisir votre province</option> */}
                            {Object.values(this.state.provinces).map(provinces=>{
                                return(
                                    <option value={provinces}>{provinces}</option>
                                );
                            })}
                        </select>
                    </div>

                </div>
                &nbsp;
            </div>
        )
    }
}